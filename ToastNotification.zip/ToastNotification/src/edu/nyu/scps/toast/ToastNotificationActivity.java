package edu.nyu.scps.toast;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class ToastNotificationActivity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        Log.d("mytag", "Start TextView");
        TextView text1 = (TextView) findViewById(R.id.text);
        text1.setText("Hello! This is a my fisrt toast!");
        Log.d("mytag", "finish TextView");

        Log.d("mytag", "Start Toast");
        Toast t = Toast.makeText(this, "I am a toast!", Toast.LENGTH_LONG);
        t.show();
        Log.d("mytag", "finish Toast");

    }
}